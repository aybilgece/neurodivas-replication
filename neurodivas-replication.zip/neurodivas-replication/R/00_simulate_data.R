# =============================================================================
# 00_simulate_data.R
# Reconstruct a synthetic NEURODIVAS dataset from PUBLISHED SUMMARY STATISTICS.
#
# We never had the raw .sav file: only the SPSS output (cell means, SDs, Ns and
# the Table 1 correlation matrix). This script rebuilds a participant-level
# dataset that, by construction, matches those published descriptives and
# reproduces the reported inferential results.
#
# METHOD
#   1. Draw correlated multivariate-normal data per cell using the published
#      4x4 correlation matrix among the dependent variables.
#   2. Within each cell, z-standardise then rescale each variable to the exact
#      published cell mean and SD  -> descriptives match by construction.
#   3. Round to the authentic Likert response grid (sums / item-means).
#
# NOTE ON REPRODUCIBILITY
#   R's RNG differs from the Python reference generator, so this script produces
#   an EQUIVALENT dataset (same descriptives & conclusions), not a byte-identical
#   one. The canonical, validated dataset used for the headline numbers in the
#   README is committed at data/neurodivas_synthetic.csv (generated and checked
#   in validation/generate_and_validate.py). Run 01_analysis.R on that file to
#   reproduce the paper exactly.
# =============================================================================

if (!requireNamespace("MASS", quietly = TRUE)) install.packages("MASS", repos = "https://cloud.r-project.org")
library(MASS)
set.seed(193)

DV <- c("SA", "ES", "PC", "PW")
R <- matrix(c(1,.74,.57,.66,  .74,1,.54,.81,  .57,.54,1,.58,  .66,.81,.58,1), 4, 4, byrow = TRUE)

# cell: list(n, means[4], sds[4]) in order SA, ES, PC, PW
cells <- list(
  list(ec="High", src="Human", n=15, m=c(9.7333,11.8667,3.0889,3.1556), s=c(3.30512,4.65781,1.01157,1.07546)),
  list(ec="High", src="AI",    n=14, m=c(9.5714,11.7143,3.3571,3.2500), s=c(2.20887,3.40652,0.57682,0.68172)),
  list(ec="Low",  src="Human", n=13, m=c(9.9231,11.3077,3.5897,3.5897), s=c(2.56455,3.77237,0.47442,0.57981)),
  list(ec="Low",  src="AI",    n=17, m=c(8.8235,10.8824,3.6275,3.1961), s=c(3.04621,4.27028,0.63336,0.85032))
)
mc_ec  <- list(High=c(2.6207,1.04928), Low=c(1.6667,0.80))
mc_src <- list(Human=c(2.75,1.62),     AI=c(4.03,1.11))

rescale <- function(x, m, s) ((x - mean(x)) / sd(x)) * s + m

parts <- lapply(cells, function(c) {
  z <- MASS::mvrnorm(c$n, mu = rep(0, 4), Sigma = R)
  for (j in 1:4) z[, j] <- rescale(z[, j], c$m[j], c$s[j])
  data.frame(
    Emotional_Context = c$ec, Source_Type = c$src,
    MC_EmotionalContext = round(pmin(pmax(rescale(rnorm(c$n), mc_ec[[c$ec]][1],  mc_ec[[c$ec]][2]), 1), 5)),
    MC_SourceType       = round(pmin(pmax(rescale(rnorm(c$n), mc_src[[c$src]][1], mc_src[[c$src]][2]), 1), 5)),
    SA = as.integer(round(pmin(pmax(z[,1], 3), 15))),
    ES = as.integer(round(pmin(pmax(z[,2], 4), 20))),
    PC = round(pmin(pmax(round(z[,3]*3)/3, 1), 5), 4),
    PW = round(pmin(pmax(round(z[,4]*3)/3, 1), 5), 4)
  )
})
d <- do.call(rbind, parts)
dir.create("data", showWarnings = FALSE)
write.csv(d, "data/neurodivas_synthetic_R.csv", row.names = FALSE)
cat("Wrote data/neurodivas_synthetic_R.csv  (N =", nrow(d), ")\n")
cat("For the validated canonical dataset, use data/neurodivas_synthetic.csv\n")
