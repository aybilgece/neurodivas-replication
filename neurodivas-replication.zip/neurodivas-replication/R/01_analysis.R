# =============================================================================
# 01_analysis.R
# Reproduce the NEURODIVAS results section from the committed synthetic dataset.
#
#   (1) Manipulation-check independent-samples t-test (emotional context)
#   (2) Pearson correlation matrix among the four dependent variables (Table 1)
#   (3) Two-way (2x2) MANOVA  -> Pillai's trace, SPSS-style Type III
#   (4) Follow-up univariate test for perceived competence (the significant DV)
#
# Run from the repository root:   Rscript R/01_analysis.R
# =============================================================================

# ---- packages -------------------------------------------------------------
need <- c("car", "rstatix", "ggplot2", "dplyr", "tidyr")
for (p in need) if (!requireNamespace(p, quietly = TRUE))
  install.packages(p, repos = "https://cloud.r-project.org")
suppressMessages({library(car); library(rstatix); library(ggplot2); library(dplyr); library(tidyr)})

dir.create("outputs", showWarnings = FALSE)
d <- read.csv("data/neurodivas_synthetic.csv", stringsAsFactors = TRUE)
DV <- c("SA", "ES", "PC", "PW")
cat(sprintf("Loaded %d participants across %d cells.\n\n", nrow(d), nlevels(d$Emotional_Context) * nlevels(d$Source_Type)))

# ---- (1) manipulation check: emotional context ----------------------------
cat("== (1) Manipulation check t-test (MC_EmotionalContext by Emotional_Context) ==\n")
tt <- d %>% t_test(MC_EmotionalContext ~ Emotional_Context, var.equal = TRUE) %>% add_significance()
es <- d %>% cohens_d(MC_EmotionalContext ~ Emotional_Context)
print(tt); print(es)
mc_desc <- d %>% group_by(Emotional_Context) %>%
  summarise(M = mean(MC_EmotionalContext), SD = sd(MC_EmotionalContext), n = n(), .groups = "drop")
print(mc_desc)

# ---- (2) correlation matrix (Table 1) -------------------------------------
cat("\n== (2) Pearson correlations among DVs (paper Table 1) ==\n")
cor_tab <- d %>% select(all_of(DV)) %>% cor_mat()
print(cor_tab)
write.csv(cor_tab, "outputs/correlation_matrix.csv", row.names = FALSE)

# ---- (3) two-way MANOVA, SPSS-style Type III Pillai -----------------------
cat("\n== (3) Two-way MANOVA (Pillai's trace, Type III) ==\n")
options(contrasts = c("contr.sum", "contr.poly"))   # effect coding -> matches SPSS Type III
fit <- lm(cbind(SA, ES, PC, PW) ~ Emotional_Context * Source_Type, data = d)
man <- car::Manova(fit, type = 3, test.statistic = "Pillai")
print(summary(man, multivariate = TRUE, univariate = FALSE))

# ---- (4) follow-up: perceived competence by emotional context -------------
cat("\n== (4) Follow-up univariate test: Perceived Competence by Emotional_Context ==\n")
pc_desc <- d %>% group_by(Emotional_Context) %>%
  summarise(M = mean(PC), SD = sd(PC), n = n(), .groups = "drop")
print(pc_desc)
pc_test <- d %>% t_test(PC ~ Emotional_Context, var.equal = TRUE) %>% add_significance()
print(pc_test)

# ---- figures --------------------------------------------------------------
long <- d %>% select(Emotional_Context, Source_Type, all_of(DV)) %>%
  pivot_longer(all_of(DV), names_to = "Measure", values_to = "Score")
p <- ggplot(long, aes(Emotional_Context, Score, fill = Source_Type)) +
  geom_boxplot(outlier.size = .6) +
  facet_wrap(~ Measure, scales = "free_y") +
  labs(title = "Perceived social attributes by emotional context and source type",
       subtitle = "NEURODIVAS reproduction (synthetic data from published summary statistics)",
       x = NULL, fill = "Source") +
  theme_minimal(base_size = 12)
ggsave("outputs/boxplots_by_condition.png", p, width = 9, height = 6, dpi = 150)
cat("\nFigures + tables written to outputs/.\n")
