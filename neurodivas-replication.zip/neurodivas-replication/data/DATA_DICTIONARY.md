# Data dictionary — neurodivas_synthetic.csv

Synthetic dataset (N = 59) reconstructed from the published summary statistics.

| Column | Type | Description | Range / levels |
|---|---|---|---|
| `Emotional_Context` | factor | Vignette emotional salience (IV) | High, Low |
| `Source_Type` | factor | Advice source (IV) | Human, AI |
| `MC_EmotionalContext` | int | Manipulation-check: perceived importance of context | 1–5 |
| `MC_SourceType` | int | Manipulation-check: fit to intended source format | 1–5 |
| `SA` | int | Social Attraction (sum of 3 items) | 3–15 |
| `ES` | int | Emotional Support (sum of 4 items) | 4–20 |
| `PC` | num | Perceived Competence (mean of 3 items) | 1–5 |
| `PW` | num | Perceived Warmth (mean of 3 items) | 1–5 |
| `Age` | int | Synthetic age (descriptive only) | 18–29 |
| `Sex` | factor | Synthetic sex (descriptive only) | Male, Female, Undisclosed |
| `SES` | int | Synthetic subjective SES ladder (descriptive only) | 1–10 |

Cell sizes: High-Human = 15, High-AI = 14, Low-Human = 13, Low-AI = 17.
