"""Reconstruct the NEURODIVAS dataset from published summary statistics and validate
reproduction of the reported manipulation-check t-test, correlation matrix, and 2x2 MANOVA.
Reference validator for the committed dataset (data/neurodivas_synthetic.csv)."""
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.multivariate.manova import MANOVA

SEED = 193
DV = ['SA','ES','PC','PW']
R = np.array([[1,.74,.57,.66],[.74,1,.54,.81],[.57,.54,1,.58],[.66,.81,.58,1]])
order = [('High','Human'),('High','AI'),('Low','Human'),('Low','AI')]
cells = {
 ('High','Human'):(15,[(9.7333,3.30512),(11.8667,4.65781),(3.0889,1.01157),(3.1556,1.07546)]),
 ('High','AI'):    (14,[(9.5714,2.20887),(11.7143,3.40652),(3.3571,0.57682),(3.2500,0.68172)]),
 ('Low','Human'):  (13,[(9.9231,2.56455),(11.3077,3.77237),(3.5897,0.47442),(3.5897,0.57981)]),
 ('Low','AI'):     (17,[(8.8235,3.04621),(10.8824,4.27028),(3.6275,0.63336),(3.1961,0.85032)]),
}
MC_EC  = {'High':(2.6207,1.04928),'Low':(1.6667,0.80)}
MC_SRC = {'Human':(2.75,1.62),'AI':(4.03,1.11)}

def rescale(col,m,sd):
    col=(col-col.mean())/col.std(ddof=1); return col*sd+m

rng=np.random.default_rng(SEED); L=np.linalg.cholesky(R)
# --- PASS 1: draw the 4 DVs for every cell FIRST (identical stream to the validated run) ---
blocks=[]
for ec,src in order:
    n,st=cells[(ec,src)]
    z=rng.standard_normal((n,4))@L.T
    for j in range(4): z[:,j]=rescale(z[:,j],st[j][0],st[j][1])
    df=pd.DataFrame(z,columns=DV); df['Emotional_Context']=ec; df['Source_Type']=src
    blocks.append(df)
d=pd.concat(blocks,ignore_index=True)
# --- PASS 2: manipulation checks + demographics drawn AFTER all DV draws ---
for col,mp in [('MC_EmotionalContext',MC_EC)]:
    vals=[]
    for ec,src in order:
        n=cells[(ec,src)][0]; vals.append(rescale(rng.standard_normal(n),*mp[ec]))
    d[col]=np.concatenate(vals)
vals=[]
for ec,src in order:
    n=cells[(ec,src)][0]; vals.append(rescale(rng.standard_normal(n),*MC_SRC[src]))
d['MC_SourceType']=np.concatenate(vals)
n=len(d)
d['Age']=rescale(rng.standard_normal(n),21.77,2.29).round().clip(18,29).astype(int)
d['SES']=rescale(rng.standard_normal(n),6.32,1.84).round().clip(1,10).astype(int)
sex=(['Male']*30+['Female']*26+['Undisclosed']*3); rng.shuffle(sex); d['Sex']=sex
# round to authentic item grids
d['SA']=d['SA'].round().clip(3,15).astype(int)
d['ES']=d['ES'].round().clip(4,20).astype(int)
d['PC']=(np.round(d['PC']*3)/3).clip(1,5).round(4)
d['PW']=(np.round(d['PW']*3)/3).clip(1,5).round(4)
d['MC_EmotionalContext']=d['MC_EmotionalContext'].round().clip(1,5).astype(int)
d['MC_SourceType']=d['MC_SourceType'].round().clip(1,5).astype(int)
d=d[['Emotional_Context','Source_Type','MC_EmotionalContext','MC_SourceType','SA','ES','PC','PW','Age','Sex','SES']]
d.to_csv('../data/neurodivas_synthetic.csv',index=False)

print("=== REPRODUCTION REPORT ===  N=%d"%len(d))
hi=d[d.Emotional_Context=='High']['MC_EmotionalContext']; lo=d[d.Emotional_Context=='Low']['MC_EmotionalContext']
t,p=stats.ttest_ind(hi,lo)
print("MC t-test : High M=%.2f SD=%.2f | Low M=%.2f SD=%.2f | t(%d)=%.2f p=%.3f   [pub t(57)=3.93 p=.001]"%(
 hi.mean(),hi.std(ddof=1),lo.mean(),lo.std(ddof=1),n-2,t,p))
c=d[DV].corr()
print("corr      : SA-ES %.2f(.74) SA-PC %.2f(.57) SA-PW %.2f(.66) ES-PC %.2f(.54) ES-PW %.2f(.81) PC-PW %.2f(.58)"%(
 c.loc['SA','ES'],c.loc['SA','PC'],c.loc['SA','PW'],c.loc['ES','PC'],c.loc['ES','PW'],c.loc['PC','PW']))
m=MANOVA.from_formula('SA+ES+PC+PW ~ C(Emotional_Context,Sum)*C(Source_Type,Sum)',data=d).mv_test()
for k,lab in [('C(Emotional_Context, Sum)','EC'),('C(Source_Type, Sum)','Source'),('C(Emotional_Context, Sum):C(Source_Type, Sum)','EC*Source')]:
    pi=m.results[k]['stat'].loc["Pillai's trace"]; print("MANOVA %-9s: Pillai F=%.2f p=%.3f"%(lab,pi['F Value'],pi['Pr > F']))
print("           [pub EC F=3.59 p=.012 | Source F=1.17 p=.334 | EC*Source F=0.90 p=.467]")
print("PostHoc PC: Low M=%.2f vs High M=%.2f   [pub 3.60 vs 3.22 p=.043]"%(
 d[d.Emotional_Context=='Low']['PC'].mean(),d[d.Emotional_Context=='High']['PC'].mean()))
